package com.example.flutter_live_location_gmap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
